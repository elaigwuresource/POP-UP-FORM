
const close = document.getElementById("close"); //close
const open = document.getElementById("open"); //open
const modal = document.getElementById("modal"); //modal



open.addEventListener("click", () => modal.classList.add("show-modal"));

close.addEventListener("click", () => modal.classList.remove("show-modal"));

window.addEventListener("click", (e) => {
    e.target === modal ? modalclassList.remove("show-modal") : false;

});
